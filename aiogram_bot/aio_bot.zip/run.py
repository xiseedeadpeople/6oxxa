# https://habr.com/ru/companies/amvera/articles/820527/

# from decouple import Config

# Получаем переменные окружения
# API_KEY = config('API_KEY')  # Читает значение API_KEY из .env
API_KEY = 'API_KEY'  # Читает значение API_KEY из .env

# DEBUG = config('DEBUG', cast=bool)  # Приведение к типу boolean
# DEBUG = 'DEBUG', cast=bool  # Приведение к типу boolean

# # Использование переменных
# if DEBUG:
#     print("Debug mode is ON.")

print(f"API Key: {API_KEY}")
